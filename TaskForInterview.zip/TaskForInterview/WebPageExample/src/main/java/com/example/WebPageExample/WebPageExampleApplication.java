package com.example.WebPageExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebPageExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebPageExampleApplication.class, args);
	}

}
