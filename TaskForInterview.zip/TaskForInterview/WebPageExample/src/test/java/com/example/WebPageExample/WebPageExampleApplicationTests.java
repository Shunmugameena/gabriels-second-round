package com.example.WebPageExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebPageExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
